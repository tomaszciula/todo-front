import React from "react"
import { HeaderWrapper } from "./Header.styled"

const Header = () => {
    return(
        <HeaderWrapper>TO DO LIST by TC</HeaderWrapper>
    )
}

export default Header