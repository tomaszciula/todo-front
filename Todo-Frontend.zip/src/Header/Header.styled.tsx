import styled from "styled-components";

export const HeaderWrapper = styled.div`
    width: 100vw;
    display: flex;
    justify-content: center;
    font-family: 'Indie Flower';
    font-size: 50px;
    color: black;
`