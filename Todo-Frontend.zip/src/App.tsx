import React from "react";
import MainView from "./MainView/MainView";

function App() {
  return <MainView />;
}

export default App;
