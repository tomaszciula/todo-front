import styled from "styled-components";

export const MainViewWrapper = styled.div`
    font-Family: "Indie Flower";
    font-size: 25px;
    color: white;
`